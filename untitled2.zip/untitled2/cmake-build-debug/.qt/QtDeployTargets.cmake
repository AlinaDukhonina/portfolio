set(__QT_DEPLOY_TARGET_untitled2_FILE /Users/alina/Desktop/untitled2/cmake-build-debug/untitled2)
set(__QT_DEPLOY_TARGET_untitled2_TYPE EXECUTABLE)
