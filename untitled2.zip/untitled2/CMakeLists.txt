cmake_minimum_required(VERSION 4.2)
project(untitled2)

set(CMAKE_CXX_STANDARD 20)
# Укажите путь к вашей установке Qt
set(CMAKE_PREFIX_PATH "/opt/homebrew/Cellar/qt/6.11.1") # Подставьте ваш путь!

# Включите автоматическую обработку сигналов/слотов (moc), UI (uic) и ресурсов (rcc)
set(CMAKE_AUTOMOC ON)
set(CMAKE_AUTOUIC ON)
set(CMAKE_AUTORCC ON)

find_package(Qt6 COMPONENTS Core Gui Widgets Multimedia REQUIRED) # или Qt5


add_executable(untitled2 main.cpp)

target_link_libraries(untitled2 Qt6::Core Qt6::Gui Qt6::Widgets Qt6::Multimedia)