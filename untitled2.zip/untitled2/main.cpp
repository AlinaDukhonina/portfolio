#include <iostream>
#include <fstream>
using namespace std;
#include <string>
#include <vector>
#include <algorithm>
#include <numeric>
#include <ctime>
#include <QtWidgets>
#include <QtGui>
// #include <QAmbientSound>
// #include <QAudioEngine>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QSoundEffect>
#include <QUrl>

class Player: public QObject {
private:
    int x;
    int y;
    int speed;
    QRect rect;
    QPixmap sprite;
public:
    Player(int x, int y, int speed, QObject* parent): QObject(parent) {
        rect = QRect(x,y,100,100);
        sprite = QPixmap("/Users/alina/Desktop/untitled2/player.PNG");
        if (!sprite.isNull()) {
            sprite = sprite.scaled(rect.width(),rect.height(), Qt::KeepAspectRatio);
        }
        this->speed = speed;
    }

    void draw(QPainter* painter) {
        painter->drawPixmap(rect.x(), rect.y(), sprite);
    }

    void moveLeft() {
        if (rect.x()>0) {
            rect.setX(rect.x() - speed);
        }
    }
    void moveRight() {
        if (rect.x()<1300) {
            rect.setX(rect.x() + speed);
        }
    }

    int getX() {
        return rect.x();
    }

    int getY() {
        return rect.y();
    }
};

class Arrow: public QObject {
private:
    int x;
    int y;
    int speed;
    int multiply = 0;
    QRect rect;
    QPixmap sprite;
public:
    Arrow(int x, int y, int speed, QObject* parent): QObject(parent) {
        rect = QRect(x,y,20,70);
        sprite = QPixmap("/Users/alina/Desktop/untitled2/arrow.PNG");
        if (!sprite.isNull()) {
            sprite = sprite.scaled(rect.width(),rect.height(), Qt::KeepAspectRatio);
        }
        this->speed = speed;
        this->multiply = multiply;
    }

    void draw(QPainter* painter) {
        painter->drawPixmap(rect.x(), rect.y(), sprite);
    }

    void moveUp() {
        if (rect.y()>0) {
            // rect.setY(rect.y() - speed);
            rect.translate(0,-speed);
        }
        if (rect.y()==-70) {
            // sprite.kill();
        }
    }

    int getY() {
        return rect.y();
    }

    QRect getRect() {
        return rect;
    }

    void increaseMultiply() {
        multiply++;
    }

    int getMultiply() {
        return multiply;
    }

    void zeroMultiply() {
        multiply = 0;
    }
};

class Target: public QObject {
private:
    int x;
    int y;
    int speed;
    QRect rect;
    QPixmap sprite;
    int direction;
public:
    Target(int y, int speed, int direction, QObject* parent): QObject(parent) {
        if (direction==1) {
            x = 1400 - 70;
        }
        else {
            x = 1;
        }
        rect = QRect(x,y,70,70);
        sprite = QPixmap("/Users/alina/Desktop/untitled2/target.PNG");
        if (!sprite.isNull()) {
            sprite = sprite.scaled(rect.width(),rect.height(), Qt::KeepAspectRatio);
        }
        this->speed = speed;
        this->direction = direction;
    }

    void draw(QPainter* painter) {
        painter->drawPixmap(rect.x(), rect.y(), sprite);
    }

    void moveHorizontaly() {
        if (direction == 1) {
            if (rect.x()>0) {
                rect.translate(-speed,0);
            }
        }
        else {
            if (rect.x()>0) {
                rect.translate(speed,0);
            }
        }
    }

    int getX() {
        return rect.x();
    }

    int getDirection() {
        return direction;
    }

    QRect getRect() {
        return rect;
    }
};

class Block: public QObject {
private:
    int x;
    int y;
    int speed;
    QRect rect;
    QPixmap sprite;
    int direction;
public:
    Block(int y, int speed, int direction, QObject* parent): QObject(parent) {
        if (direction==1) {
            x = 1400 - 70;
        }
        else {
            x = 1;
        }
        rect = QRect(x,y,70,70);
        sprite = QPixmap("/Users/alina/Desktop/untitled2/block.PNG");
        if (!sprite.isNull()) {
            sprite = sprite.scaled(rect.width(),rect.height(), Qt::KeepAspectRatio);
        }
        this->speed = speed;
        this->direction = direction;
    }

    void draw(QPainter* painter) {
        painter->drawPixmap(rect.x(), rect.y(), sprite);
    }

    void moveHorizontaly() {
        if (direction == 1) {
            if (rect.x()>0) {
                rect.translate(-speed,0);
            }
        }
        else {
            if (rect.x()>0) {
                rect.translate(speed,0);
            }
        }
    }

    int getX() {
        return rect.x();
    }

    int getDirection() {
        return direction;
    }

    QRect getRect() {
        return rect;
    }
};

class BonusArrow: public QObject {
private:
    int x;
    int y;
    int speed;
    QRect rect;
    QPixmap sprite;
    int direction;
public:
    BonusArrow(int y, int speed, int direction, QObject* parent): QObject(parent) {
        if (direction==1) {
            x = 1400 - 70;
        }
        else {
            x = 1;
        }
        rect = QRect(x,y,70,70);
        sprite = QPixmap("/Users/alina/Desktop/untitled2/bonus_arrow.PNG");
        if (!sprite.isNull()) {
            sprite = sprite.scaled(rect.width(),rect.height(), Qt::KeepAspectRatio);
        }
        this->speed = speed;
        this->direction = direction;
    }

    void draw(QPainter* painter) {
        painter->drawPixmap(rect.x(), rect.y(), sprite);
    }

    void moveHorizontaly() {
        if (direction == 1) {
            if (rect.x()>0) {
                rect.translate(-speed,0);
            }
        }
        else {
            if (rect.x()>0) {
                rect.translate(speed,0);
            }
        }
    }

    int getX() {
        return rect.x();
    }

    int getDirection() {
        return direction;
    }

    QRect getRect() {
        return rect;
    }
};

class Game: public QWidget {
private:
    QList<Target*> targets;
    QList<Arrow*> arrows;
    QList<BonusArrow*> bonusArrows;
    QList<Block*> blocks;
    Player* player;
    QTimer* game_timer;
    QTimer* spawn_timer;
    int score = 0;
    int record = 0;
    int frame_bullet_arrow = 90;
    int frame_bullet_target = 160;
    int frame_bullet_block = 320;
    int frame_bullet_bonus_arrow = 160;
    bool game_over = false;
    int frame = 0;

    QLabel* score_text;
    QLabel* gameOverText;
    QPushButton* start_button;
    QRect rect;
    QPixmap sprite;
    QMediaPlayer* background_music;
    QAudioOutput* audio_output;

public:
    Game(): QWidget(nullptr) {
        setFixedSize(1400, 750);
        rect = QRect(0,0,1400,750);
        setWindowTitle("Kill it all");
        sprite = QPixmap("/Users/alina/Desktop/untitled2/game_background.PNG");
        if (!sprite.isNull()) {
            sprite = sprite.scaled(rect.width(),rect.height(), Qt::KeepAspectRatio);
        }

        audio_output = new QAudioOutput(this);
        background_music = new QMediaPlayer(this);
        background_music->setAudioOutput(audio_output);
        background_music->setSource(QUrl("/Users/alina/Desktop/untitled2/24b0d8ed4ae4cb2.wav"));
        background_music->setLoops(QMediaPlayer::Infinite);
        audio_output->setVolume(0.01);
        background_music->play();

        std::ifstream file("record.bin", std::ios::binary);
        if (file.is_open()) {
            file.read((char*)&record, sizeof(record));
        }
        score_text = new QLabel(QString::number(score) + " | " + QString::number(record), this);
        score_text->move(50, 25);
        score_text->resize(700, 70);
        score_text->setStyleSheet("font-size: 50px; color: rgb(255,0,0); text-align: center;");

        gameOverText = new QLabel("GAME OVER", this);
        gameOverText->move(580, 200);
        gameOverText->setStyleSheet("font-size: 50px; color: rgb(255,0,0); text-align: center;");
        gameOverText->hide();

        start_button = new QPushButton("START", this);
        start_button->move(615, 300);
        start_button->setStyleSheet("font-size: 50px; color: rgb(255,0,0); background-color: rgb(0,0,0); border: 2px, solid, rgb(255,0,0); padding-top: 10px; padding-bottom: 10px; padding-left: 15px; padding-right: 15px; border-radius: 10px;");

        player = new Player(650, 550, 10, this);

        connect(start_button, &QPushButton::clicked, this, &Game::startGame);


    };

    void startGame() {
        game_timer = new QTimer(this);
        connect(game_timer, &QTimer::timeout, this, &Game::updateGame);
        game_timer->start(16);
        start_button->hide();
        gameOverText->hide();
        score = 0;
        frame = 0;
        targets.clear();
        bonusArrows.clear();
        arrows.clear();
        blocks.clear();
        std::ifstream file("record.bin", std::ios::binary);
        if (file.is_open()) {
            file.read((char*)&record, sizeof(record));
        }
    }

    void keyPressEvent(QKeyEvent* event) {
        switch (event->key()) {
            case Qt::Key_A :
                player->moveLeft();
                break;
            case Qt::Key_D :
                player->moveRight();
                break;
        }
    }

    void paintEvent(QPaintEvent* event) {
        QPainter painter(this);
        painter.drawPixmap(rect.x(), rect.y(), sprite);
        player->draw(&painter);
        for (Arrow* arrow : arrows) {
            arrow->draw(&painter);
        }
        for (Target* target : targets) {
            target->draw(&painter);
        }
        for (Block* block : blocks) {
            block->draw(&painter);
        }
        for (BonusArrow* bonusArrow : bonusArrows) {
            bonusArrow->draw(&painter);
        }
    }

    void checkCollision() {
        int k = 0;
        int base_score = 5;
        for (int i = arrows.size() - 1; i >= 0; i--) {
            Arrow* arrow = arrows.at(i);
            QRect arrowRect = arrow->getRect();
            for (int j = targets.size() - 1; j >= 0; j--) {
                Target* target = targets.at(j);
                QRect targetRect = target->getRect();
                if (arrowRect.intersects(targetRect)) {
                    k = arrow->getMultiply();
                    for (int n = 0; n<=k; n++) {
                        base_score *= 2;
                    }
                    score += base_score;
                    base_score = 5;
                    delete arrow;
                    arrows.removeAt(i);
                    delete target;
                    targets.removeAt(j);
                    break;
                }
            }
        }
        for (int i = arrows.size() - 1; i >= 0; i--) {
            Arrow* arrow = arrows.at(i);
            QRect arrowRect = arrow->getRect();
            for (int j = blocks.size() - 1; j >= 0; j--) {
                Block* block = blocks.at(j);
                QRect blockRect = block->getRect();
                if (arrowRect.intersects(blockRect)) {
                    delete arrow;
                    arrows.removeAt(i);
                    break;
                }
            }
        }
        for (int i = arrows.size() - 1; i >= 0; i--) {
            Arrow* arrow = arrows.at(i);
            QRect arrowRect = arrow->getRect();
            for (int j = bonusArrows.size() - 1; j >= 0; j--) {
                BonusArrow* bonus_arrow = bonusArrows.at(j);
                QRect bonus_arrow_Rect = bonus_arrow->getRect();
                if (arrowRect.intersects(bonus_arrow_Rect)) {
                    k = arrow->getMultiply();
                    for (int n = 0; n<=k; n++) {
                        base_score *= 2;
                    }
                    score += base_score;
                    base_score = 5;
                    arrow->increaseMultiply();
                    delete bonus_arrow;
                    bonusArrows.removeAt(j);
                    break;
                }
            }
        }
    }

    void FinishCheck() {
        game_timer->stop();
        gameOverText->show();
        start_button->show();
        update();
        if (score > record) {
            std::ofstream file("record.bin", std::ios::binary);
            if (file.is_open()) {
                file.write((char*)&score, sizeof(score));
            }
        }
    }

    void updateGame() {
        update();
        score_text->setText(QString::number(score) + " | " + QString::number(record));
        checkCollision();
        frame_bullet_arrow -= 1;
        if (frame_bullet_arrow <= 0) {
            arrows.append(new Arrow(player->getX()+40, player->getY(), 30, this));
            if (frame <= 333) {
                frame_bullet_arrow = 90;
            }
            else if (frame <= 666) {
                frame_bullet_arrow = 60;
            }
            else if (frame <= 999) {
                frame_bullet_arrow = 30;
            }
        }
        checkCollision();
        frame_bullet_target -= 1;
        if (frame_bullet_target <= 0) {
            int dir = rand() % 2;
            targets.append(new Target(rand() %330 +70, 3, dir, this));
            if (frame <= 333) {
                frame_bullet_target = 180;
            }
            else if (frame <= 666) {
                frame_bullet_target = 130;
            }
            else if (frame <= 999) {
                frame_bullet_target = 80;
            }
        }
        checkCollision();
        frame_bullet_block -= 1;
        if (frame_bullet_block <= 0) {
            int dir = rand() % 2;
            blocks.append(new Block(rand() %330 +70, 1, dir, this));
            if (frame <= 333) {
                frame_bullet_block = 340;
            }
            else if (frame <= 666) {
                frame_bullet_block = 300;
            }
            else if (frame <= 999) {
                frame_bullet_block = 260;
            }
        }
        checkCollision();
        frame_bullet_bonus_arrow -= 1;
        if (frame_bullet_bonus_arrow <= 0) {
            int dir = rand() % 2;
            bonusArrows.append(new BonusArrow(rand() %330 +70, 2, dir, this));
            if (frame <= 333) {
                frame_bullet_bonus_arrow = 200;
            }
            else if (frame <= 666) {
                frame_bullet_bonus_arrow = 150;
            }
            else if (frame <= 999) {
                frame_bullet_bonus_arrow = 100;
            }
        }
        checkCollision();
        for (int i = arrows.size()-1; i >= 0; i--) {
            arrows[i]->moveUp();
            if (arrows[i]->getY() < 0) {
                delete arrows[i];
                arrows.removeAt(i);
            }
        }
        checkCollision();
        for (int i = targets.size()-1; i >= 0; i--) {
            targets[i]->moveHorizontaly();
            if (targets[i]->getDirection() == 0) {
                if (targets[i]->getX() > 1330) {
                    delete targets[i];
                    targets.removeAt(i);
                }
            }
            else {
                if (targets[i]->getX() <= 0) {
                    delete targets[i];
                    targets.removeAt(i);
                }
            }
        }
        checkCollision();
        for (int i = blocks.size()-1; i >= 0; i--) {
            blocks[i]->moveHorizontaly();
            if (blocks[i]->getDirection() == 0) {
                if (blocks[i]->getX() > 1330) {
                    delete blocks[i];
                    blocks.removeAt(i);
                }
            }
            else {
                if (blocks[i]->getX() <= 0) {
                    delete blocks[i];
                    blocks.removeAt(i);
                }
            }
        }
        checkCollision();
        for (int i = bonusArrows.size()-1; i >= 0; i--) {
            bonusArrows[i]->moveHorizontaly();
            if (bonusArrows[i]->getDirection() == 0) {
                if (bonusArrows[i]->getX() > 1330) {
                    delete bonusArrows[i];
                    bonusArrows.removeAt(i);
                }
            }
            else {
                if (bonusArrows[i]->getX() <= 0) {
                    delete bonusArrows[i];
                    bonusArrows.removeAt(i);
                }
            }
        }
        checkCollision();
        frame++;
        if (frame == 1000) {
            FinishCheck();
        }
    }
};

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    Game game;
    game.show();
    return app.exec();
}